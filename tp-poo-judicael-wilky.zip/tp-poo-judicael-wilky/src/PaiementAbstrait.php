<?php
declare(strict_types=1);

abstract class PaiementAbstrait implements MoyenPaiement
{
    protected string $payeur;

    public function __construct(string $payeur)
    {
        $this->payeur = $payeur;
    }

    public function payer(float $montant): Recu
    {
        if ($montant <= 0) {
            throw new InvalidArgumentException("Le montant doit être positif.");
        }

        $frais = $this->frais($montant);

        return new Recu($this->getLibelle(), $montant, $frais);
    }

    abstract public function frais(float $montant): float;
}
