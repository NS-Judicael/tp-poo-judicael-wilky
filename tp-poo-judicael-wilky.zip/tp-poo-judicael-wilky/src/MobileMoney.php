<?php
declare(strict_types=1);

class MobileMoney extends PaiementAbstrait
{
    private string $operateur;

    public function __construct(string $payeur, string $operateur)
    {
        parent::__construct($payeur);
        $this->operateur = $operateur;
    }

    public function getLibelle(): string
    {
        return "Mobile Money (" . $this->operateur . ")";
    }

    public function frais(float $montant): float
    {
        $frais = $montant * 0.02;

        if ($frais > 5000) {
            $frais = 5000;
        }

        return $frais;
    }
}
