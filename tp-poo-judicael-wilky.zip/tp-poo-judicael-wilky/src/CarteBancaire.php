<?php
declare(strict_types=1);

class CarteBancaire extends PaiementAbstrait
{
    private string $numeroCarte;

    public function __construct(string $payeur, string $numeroCarte)
    {
        parent::__construct($payeur);
        $this->numeroCarte = $numeroCarte;
    }

    public function getLibelle(): string
    {
        return "Carte ****" . $this->numeroCarte;
    }

    public function frais(float $montant): float
    {
        return $montant * 0.015;
    }
}
