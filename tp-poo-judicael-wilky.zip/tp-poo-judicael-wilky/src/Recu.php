<?php
declare(strict_types=1);

class Recu
{
    public function __construct(
        public readonly string $libelle,
        public readonly float $montant,
        public readonly float $frais
    ) {
    }

    public function total(): float
    {
        return $this->montant + $this->frais;
    }
}
