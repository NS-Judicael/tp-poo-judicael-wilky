<?php
declare(strict_types=1);

class Especes extends PaiementAbstrait
{
    public function getLibelle(): string
    {
        return "Espèces";
    }

    public function frais(float $montant): float
    {
        return 0;
    }
}
