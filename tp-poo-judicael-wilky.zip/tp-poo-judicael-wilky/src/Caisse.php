<?php
declare(strict_types=1);

class Caisse
{
    private float $totalJour = 0;

    public function encaisser(MoyenPaiement $p, float $m): Recu
    {
        $recu = $p->payer($m);
        $this->totalJour += $recu->total();

        return $recu;
    }

    public function getTotalJour(): float
    {
        return $this->totalJour;
    }
}
