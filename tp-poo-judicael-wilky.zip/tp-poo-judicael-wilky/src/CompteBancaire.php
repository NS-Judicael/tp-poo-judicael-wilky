<?php
declare(strict_types=1);

class CompteBancaire
{
    public function __construct(
        public readonly string $numero,
        public readonly string $titulaire
    ) {
    }

    private float $solde = 0;
    private array $historique = [];

    public function getSolde(): float
    {
        return $this->solde;
    }

    public function deposer(float $m): void
    {
        if ($m <= 0) {
            throw new InvalidArgumentException("Le montant doit être positif.");
        }

        $this->solde += $m;
        $this->historique[] = "Dépôt : " . $m . " Ar";
    }

    public function retirer(float $m): void
    {
        if ($m <= 0) {
            throw new InvalidArgumentException("Le montant doit être positif.");
        }

        if ($m > $this->solde) {
            throw new SoldeInsuffisantException("Solde insuffisant.");
        }

        $this->solde -= $m;
        $this->historique[] = "Retrait : " . $m . " Ar";
    }

    public function getHistorique(): array
    {
        return $this->historique;
    }

    public function virerVers(CompteBancaire $dest, float $m): void
    {
        $this->retirer($m);
        $dest->deposer($m);
    }
}
