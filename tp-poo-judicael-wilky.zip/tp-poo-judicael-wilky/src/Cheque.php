<?php
declare(strict_types=1);

class Cheque extends PaiementAbstrait
{
    public function getLibelle(): string
    {
        return "Chèque";
    }

    public function frais(float $montant): float
    {
        return 1000;
    }
}
