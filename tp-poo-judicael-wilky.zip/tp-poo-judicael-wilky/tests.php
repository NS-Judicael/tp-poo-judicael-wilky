<?php
declare(strict_types=1);

require 'src/SoldeInsuffisantException.php';
require 'src/CompteBancaire.php';

require 'src/MoyenPaiement.php';
require 'src/PaiementAbstrait.php';
require 'src/Recu.php';
require 'src/Especes.php';
require 'src/CarteBancaire.php';
require 'src/MobileMoney.php';
require 'src/Caisse.php';
require 'src/Cheque.php';

$a = new CompteBancaire('MG-001', 'Rakoto');
$b = new CompteBancaire('MG-002', 'Rasoa');

$a->deposer(150000);
$a->virerVers($b, 40000);

echo $a->getSolde(), ' / ', $b->getSolde(), PHP_EOL;

try {
    $b->virerVers($a, 999999);
} catch (SoldeInsuffisantException $e) {
    echo 'Refusé : ', $e->getMessage(), PHP_EOL;
}

echo $a->getSolde(), ' / ', $b->getSolde(), PHP_EOL;

$caisse = new Caisse();

$carte = new CarteBancaire("Rakoto", "1234");
$mobile = new MobileMoney("Rasoa", "MVola");

$recu1 = $caisse->encaisser($carte, 100000);
$recu2 = $caisse->encaisser($mobile, 300000);

echo "Total carte : ", $recu1->total(), PHP_EOL;
echo "Total Mobile Money : ", $recu2->total(), PHP_EOL;
echo "Total de la caisse : ", $caisse->getTotalJour(), PHP_EOL;

$cheque = new Cheque("Rakoto");
$recu3 = $caisse->encaisser($cheque, 50000);

echo "Total chèque : ", $recu3->total(), PHP_EOL;
echo "Nouveau total de la caisse : ", $caisse->getTotalJour(), PHP_EOL;
