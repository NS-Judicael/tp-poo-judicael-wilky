# TP POO en PHP

Noms des membres du binôme :
1. Nomenjanahary Solofoniaina judicael :
2. Nomenjanahary jean wilky :

## Q1. Pourquoi ne pas écrire de méthode setSolde() ?

On ne crée pas de méthode setSolde() parce que le solde doit être modifié uniquement avec les méthodes deposer() et retirer(). Cela protège le solde contre les modifications directes.

## Q2. Que se passe-t-il si on écrit $a->numero = 'X' ?

Une erreur se produit parce que la propriété numero est déclarée readonly. Elle ne peut pas être modifiée après son initialisation.

Message d'erreur attendu :
Cannot modify readonly property CompteBancaire::$numero

## Q3. getHistorique() renvoie le tableau privé : l'appelant peut-il modifier l'historique interne ? Pourquoi ?

Non. PHP utilise le mécanisme de copie sur écriture pour les tableaux. Modifier le tableau reçu ne modifie pas directement le tableau privé de l'objet.

## Q4. Pourquoi utiliser à la fois une interface et une classe abstraite ?

L'interface définit les méthodes que les moyens de paiement doivent posséder. La classe abstraite permet de partager le code commun entre les différentes classes de paiement.

## Q5. Que se passe-t-il si une classe enfant de PaiementAbstrait oublie de définir frais() ?

La classe enfant doit définir la méthode abstraite frais(). Sinon, PHP signale une erreur et la classe ne peut pas être utilisée comme une classe concrète.

## Exécution

Depuis la racine du dossier, lancer :

php tests.php
